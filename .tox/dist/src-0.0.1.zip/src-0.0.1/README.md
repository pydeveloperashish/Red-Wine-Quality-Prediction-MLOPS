THIS PROJECT IS UNDER DEVELOPMENT

create seprate env

write basic requirements.txt

download red wine quality data


git init

dvc init

dvc add data_given/winequality.csv

git add .

git commit -m "first commit"

one liner:- git add . && git commit -m "message"

git status

Push to your repo